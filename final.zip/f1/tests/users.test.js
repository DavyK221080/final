import request from "supertest";
import app from "../index";

let token;

describe("User API", () => {
  beforeAll(async () => {
    const res = await request(app).post("/users/register").send({
      username: "testuser",
      password: "password123",
      name: "Test User",
      email: "testuser@example.com",
      phoneNumber: "123-456-7890",
      profilePicture: "https://example.com/testuser.jpg",
    });
    token = (
      await request(app).post("/users/login").send({
        username: "testuser",
        password: "password123",
      })
    ).body.token;
  });

  it("should fetch users by username", async () => {
    const res = await request(app)
      .get("/users?username=testuser")
      .set("Authorization", "Bearer " + token);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toBeInstanceOf(Array);
    expect(res.body[0].username).toBe("testuser");
  });

  it("should fetch users by email", async () => {
    const res = await request(app)
      .get("/users?email=testuser@example.com")
      .set("Authorization", "Bearer " + token);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toBeInstanceOf(Array);
    expect(res.body[0].email).toBe("testuser@example.com");
  });
});
