import request from "supertest";
import app from "../index";

let token;

describe("Property API", () => {
  beforeAll(async () => {
    const res = await request(app).post("/users/register").send({
      username: "testuser",
      password: "password123",
      name: "Test User",
      email: "testuser@example.com",
      phoneNumber: "123-456-7890",
      profilePicture: "https://example.com/testuser.jpg",
    });
    token = (
      await request(app).post("/users/login").send({
        username: "testuser",
        password: "password123",
      })
    ).body.token;
  });

  it("should fetch properties by location, pricePerNight, and amenities", async () => {
    const res = await request(app)
      .get("/properties?location=Amsterdam&pricePerNight=88&amenities=Wifi")
      .set("Authorization", "Bearer " + token);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toBeInstanceOf(Array);
  });
});
