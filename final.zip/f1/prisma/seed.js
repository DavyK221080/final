import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import fs from "fs";
import path from "path";

const prisma = new PrismaClient();

const loadUsers = async () => {
  const usersData = JSON.parse(
    fs.readFileSync(path.resolve("./src/data/users.json"), "utf-8")
  ).users;
  for (const user of usersData) {
    const hashedPassword = await bcrypt.hash(user.password, 10);
    try {
      await prisma.user.upsert({
        where: { email: user.email },
        update: {},
        create: {
          id: user.id,
          username: user.username,
          password: hashedPassword,
          name: user.name,
          email: user.email,
          phoneNumber: user.phoneNumber,
          profilePicture: user.profilePicture,
        },
      });
    } catch (error) {
      console.error(
        `Error creating user with email ${user.email}:`,
        error.message
      );
    }
  }
};

const loadHosts = async () => {
  const hostsData = JSON.parse(
    fs.readFileSync(path.resolve("./src/data/hosts.json"), "utf-8")
  ).hosts;
  for (const host of hostsData) {
    const hashedPassword = await bcrypt.hash(host.password, 10);
    try {
      await prisma.host.upsert({
        where: { email: host.email },
        update: {},
        create: {
          id: host.id,
          username: host.username,
          password: hashedPassword,
          name: host.name,
          email: host.email,
          phoneNumber: host.phoneNumber,
          profilePicture: host.profilePicture,
          aboutMe: host.aboutMe,
        },
      });
    } catch (error) {
      console.error(
        `Error creating host with email ${host.email}:`,
        error.message
      );
    }
  }
};

const loadProperties = async () => {
  const propertiesData = JSON.parse(
    fs.readFileSync(path.resolve("./src/data/properties.json"), "utf-8")
  ).properties;
  for (const property of propertiesData) {
    try {
      await prisma.property.upsert({
        where: { id: property.id },
        update: {},
        create: {
          id: property.id,
          title: property.title,
          description: property.description,
          location: property.location,
          pricePerNight: property.pricePerNight,
          bedroomCount: property.bedroomCount,
          bathRoomCount: property.bathRoomCount,
          maxGuestCount: property.maxGuestCount,
          hostId: property.hostId,
        },
      });
    } catch (error) {
      console.error(
        `Error creating property with ID ${property.id}:`,
        error.message
      );
    }
  }
};

const loadBookings = async () => {
  const bookingsData = JSON.parse(
    fs.readFileSync(path.resolve("./src/data/bookings.json"), "utf-8")
  ).bookings;
  for (const booking of bookingsData) {
    try {
      await prisma.booking.upsert({
        where: { id: booking.id },
        update: {},
        create: {
          id: booking.id,
          userId: booking.userId,
          propertyId: booking.propertyId,
          checkinDate: new Date(booking.checkinDate),
          checkoutDate: new Date(booking.checkoutDate),
          numberOfGuests: booking.numberOfGuests,
          totalPrice: booking.totalPrice,
          bookingStatus: booking.bookingStatus,
        },
      });
    } catch (error) {
      console.error(
        `Error creating booking with ID ${booking.id}:`,
        error.message
      );
    }
  }
};

const loadReviews = async () => {
  const reviewsData = JSON.parse(
    fs.readFileSync(path.resolve("./src/data/reviews.json"), "utf-8")
  ).reviews;
  for (const review of reviewsData) {
    try {
      await prisma.review.upsert({
        where: { id: review.id },
        update: {},
        create: {
          id: review.id,
          userId: review.userId,
          propertyId: review.propertyId,
          rating: review.rating,
          comment: review.comment,
        },
      });
    } catch (error) {
      console.error(
        `Error creating review with ID ${review.id}:`,
        error.message
      );
    }
  }
};

const loadAmenities = async () => {
  const amenitiesData = JSON.parse(
    fs.readFileSync(path.resolve("./src/data/amenities.json"), "utf-8")
  ).amenities;
  for (const amenity of amenitiesData) {
    try {
      await prisma.amenity.upsert({
        where: { id: amenity.id },
        update: {},
        create: {
          id: amenity.id,
          name: amenity.name,
        },
      });
    } catch (error) {
      console.error(
        `Error creating amenity with ID ${amenity.id}:`,
        error.message
      );
    }
  }
};

const main = async () => {
  try {
    await loadUsers();
    await loadHosts();
    await loadProperties();
    await loadBookings();
    await loadReviews();
    await loadAmenities();
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
};

main().catch((error) => {
  console.error("Error in seed script:", error);
  process.exit(1);
});
