import * as Sentry from "@sentry/node";

Sentry.init({
  dsn: "https://ab4d54a5c8f93936449667050245e353@o4507412226441216.ingest.de.sentry.io/4507448047042640",
  integrations: [],

  tracesSampleRate: 1.0,

  profilesSampleRate: 1.0,
});
