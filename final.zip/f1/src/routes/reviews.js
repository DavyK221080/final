import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import * as reviewService from "../services/reviewService.js";

const router = express.Router();

router.get("/", authenticate, reviewService.getAllReviews);
router.post("/", authenticate, reviewService.createReview);
router.get("/:id", authenticate, reviewService.getReviewById);
router.put("/:id", authenticate, reviewService.updateReview);
router.delete("/:id", authenticate, reviewService.deleteReview);

export default router;
