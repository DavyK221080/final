import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import * as amenityService from "../services/amenityService.js";

const router = express.Router();

router.get("/", authenticate, amenityService.getAllAmenities);
router.post("/", authenticate, amenityService.createAmenity);
router.get("/:id", authenticate, amenityService.getAmenityById);
router.put("/:id", authenticate, amenityService.updateAmenity);
router.delete("/:id", authenticate, amenityService.deleteAmenity);

export default router;
