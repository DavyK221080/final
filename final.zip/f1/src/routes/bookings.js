import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import * as bookingService from "../services/bookingService.js";

const router = express.Router();

router.get("/", authenticate, bookingService.getAllBookings);
router.post("/", authenticate, bookingService.createBooking);
router.get("/:id", authenticate, bookingService.getBookingById);
router.put("/:id", authenticate, bookingService.updateBooking);
router.delete("/:id", authenticate, bookingService.deleteBooking);

export default router;
