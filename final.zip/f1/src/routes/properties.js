import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import * as propertyService from "../services/propertyService.js";

const router = express.Router();

router.get("/", authenticate, propertyService.getAllProperties);
router.post("/", authenticate, propertyService.createProperty);
router.get("/:id", authenticate, propertyService.getPropertyById);
router.put("/:id", authenticate, propertyService.updateProperty);
router.delete("/:id", authenticate, propertyService.deleteProperty);

export default router;
