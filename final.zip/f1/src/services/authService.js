import pkg from "@prisma/client";
const { PrismaClient } = pkg;
const prisma = new PrismaClient();

export const getUserById = async (id) => {
  return await prisma.user.findUnique({
    where: { id },
  });
};
