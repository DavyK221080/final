import "../instrument.mjs"; // Adjust the path as necessary

import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import users from "./routes/users.js";
import hosts from "./routes/hosts.js";
import properties from "./routes/properties.js";
import amenities from "./routes/amenities.js";
import bookings from "./routes/bookings.js";
import reviews from "./routes/reviews.js";
import * as Sentry from "@sentry/node";

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use("/users", users);
app.use("/hosts", hosts);
app.use("/properties", properties);
app.use("/amenities", amenities);
app.use("/bookings", bookings);
app.use("/reviews", reviews);

// Error handling middleware
app.use((err, req, res, next) => {
  Sentry.captureException(err);
  res.status(500).json({
    error: "An error occurred on the server, please double-check your request!",
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
