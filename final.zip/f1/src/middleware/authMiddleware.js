import * as authService from "../services/authService.js";

export const authenticate = (req, res, next) => {};
